// Importaciones necesarias para crear un componente Angular
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

// Decorador @Component: Define la configuración del componente
@Component({
  // Selector: Etiqueta HTML personalizada para usar este componente
  selector: 'app-navbar',
  // standalone: true - Indica que es un componente independiente (no necesita NgModule)
  standalone: true,
  // imports: Módulos que este componente necesita para funcionar
  imports: [CommonModule],
  // templateUrl: Archivo HTML que contiene la plantilla del componente
  templateUrl: './Navbar.component.html',
})
// Clase del componente: Contiene la lógica y propiedades del componente
export class NavbarComponent {
  // Propiedades del componente
  title = 'PokéAPI Angular';
  
  // Métodos del componente
  onHomeClick(): void {
    console.log('Home clicked');
  }
  
  onAboutClick(): void {
    console.log('About clicked');
  }
}