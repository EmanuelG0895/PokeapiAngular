import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PokemonCardComponent } from './pokemonCard/PokemonCard.component';
import { PokemonService } from '../app/services/pokemon.service';

@Component({
  selector: 'app-pokemon-list',
  standalone: true,
  imports: [CommonModule, PokemonCardComponent],
  templateUrl: './PokemonList.component.html',
})
export class PokemonListComponent implements OnInit {
  loading = true;
  pokemonList: any[] = [];
  error: string | null = null;

  constructor(private pokemonService: PokemonService) {}

  ngOnInit(): void {
    this.loadPokemonList();
  }

  loadPokemonList(): void {
    console.log('Loading Pokémon list...');
    this.loading = true;
    this.error = null;

    this.pokemonService.getPokemonListWithDetails(90, 0).subscribe({
      next: (pokemonList) => {
        this.pokemonList = pokemonList;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading Pokémon:', error);
        this.error = 'Error al cargar los Pokémon. Intenta de nuevo.';
        this.loading = false;
      },
    });
  }
}
