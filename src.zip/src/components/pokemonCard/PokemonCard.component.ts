// Importaciones necesarias para crear un componente Angular
import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

// Decorador @Component: Define la configuración del componente
@Component({
  // Selector: Etiqueta HTML personalizada para usar este componente
  selector: 'app-pokemon-card',
  // standalone: true - Indica que es un componente independiente (no necesita NgModule)
  standalone: true,
  // imports: Módulos que este componente necesita para funcionar
  imports: [CommonModule],
  // templateUrl: Archivo HTML que contiene la plantilla del componente
  templateUrl: './PokemonCard.component.html',
})
// Clase del componente: Contiene la lógica y propiedades del componente
export class PokemonCardComponent {
  // @Input permite recibir datos desde el componente padre
  @Input() pokemonData: any = {
    id: 1,
    name: 'pikachu',
    sprites: {
      other: {
        'official-artwork': {
          front_default: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png'
        }
      }
    },
    species: {
      name: 'pikachu'
    }
  };

  // Constructor para inyectar el Router
  constructor(private router: Router) {}

  // Método para navegar al detalle del Pokémon
  navigateToDetail(pokemonName: string): void {
    this.router.navigate(['/pokemon-detail', pokemonName]);
  }

  // Método para obtener la imagen del Pokémon con fallback
  getPokemonImage(): string {
    const officialArtwork = this.pokemonData?.sprites?.other?.['official-artwork']?.front_default;
    return officialArtwork || '/images/default-pokemon.svg';
  }

  // Método para obtener el nombre del Pokémon
  getPokemonName(): string {
    return this.pokemonData?.species?.name || this.pokemonData?.name || 'Unknown';
  }
} 