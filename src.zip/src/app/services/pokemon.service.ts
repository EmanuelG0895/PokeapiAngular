// Importaciones necesarias para el servicio HTTP
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map, forkJoin, switchMap } from 'rxjs';

// Interfaz para la respuesta de la lista de Pokémon
interface PokemonListResponse {
  count: number;
  next: string | null;
  previous: string | null;
  results: Array<{
    name: string;
    url: string;
  }>;
}

// Interfaz para los datos completos de un Pokémon
interface PokemonData {
  id: number;
  name: string;
  sprites: {
    other: {
      'official-artwork': {
        front_default: string;
      };
    };
  };
  species: {
    name: string;
  };
}

@Injectable({
  providedIn: 'root'
})
export class PokemonService {
  // URL base de la PokeAPI
  private baseUrl = 'https://pokeapi.co/api/v2';

  constructor(private http: HttpClient) {}

  // Obtener lista de Pokémon con paginación
  getPokemonList(limit: number = 20, offset: number = 0): Observable<PokemonListResponse> {
    const url = `${this.baseUrl}/pokemon?limit=${limit}&offset=${offset}`;
    return this.http.get<PokemonListResponse>(url);
  }

  // Obtener datos completos de un Pokémon por URL
  getPokemonByUrl(url: string): Observable<PokemonData> {
    return this.http.get<PokemonData>(url);
  }

  // Obtener datos completos de un Pokémon por nombre
  getPokemonByName(name: string): Observable<PokemonData> {
    const url = `${this.baseUrl}/pokemon/${name}`;
    return this.http.get<PokemonData>(url);
  }

  // Obtener lista completa de Pokémon con datos detallados
  getPokemonListWithDetails(limit: number = 20, offset: number = 0): Observable<PokemonData[]> {
    return this.getPokemonList(limit, offset).pipe(
      switchMap(response => {
        // Crear un array de observables para obtener los datos detallados de cada Pokémon
        const pokemonObservables = response.results.map(pokemon => 
          this.getPokemonByUrl(pokemon.url)
        );
        
        // Usar forkJoin para hacer todas las peticiones en paralelo
        return forkJoin(pokemonObservables);
      })
    );
  }
} 