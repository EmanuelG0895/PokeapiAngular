import { Routes } from '@angular/router';

export const routes: Routes = [
  // Rutas vacías ya que el contenido se renderiza directamente en App
];
